import distances
import packages

# I decided to use lists for each truck's delivery and distances here.
# They're passed into the distance, time, and package functions

first_truck_delivery = []
second_truck_delivery = []
third_truck_delivery = []
first_truck_distance = []
second_truck_distance = []
third_truck_distance = []

# I created a separate list for each of the times a truck leaves the hub

first_truck_departure = ['08:00:00']
second_truck_departure = ['09:05:00']
third_truck_departure = ['11:15:00']

# Each function here iterates through the delivery list and sets the beginning delivery time to the departure time
#O(n)

for i, value in enumerate(packages.get_first_truck_deliveries()):
    packages.get_first_truck_deliveries()[i][8] = first_truck_departure[0]
    first_truck_delivery.append(
        packages.get_first_truck_deliveries()[i])

for i, value in enumerate(packages.get_second_truck_deliveries()):
    packages.get_second_truck_deliveries()[i][8] = second_truck_departure[0]
    second_truck_delivery.append(
        packages.get_second_truck_deliveries()[i])

for i, value in enumerate(packages.get_third_truck_deliveries()):
    packages.get_third_truck_deliveries()[i][8] = third_truck_departure[0]
    third_truck_delivery.append(
        packages.get_third_truck_deliveries()[i])

# the functions here compare the address names in the delivery lists to the address.csv
# O(n^2)

for i, j in enumerate(first_truck_delivery):
    for k in distances.get_addresses():
        if j[1] == k[2]:
            first_truck_distance.append(j[0])
            first_truck_delivery[i][9] = k[0]

for i, j in enumerate(second_truck_delivery):
    for k in distances.get_addresses():
        if j[1] == k[2]:
            second_truck_distance.append(j[0])
            second_truck_delivery[i][9] = k[0]

for i, j in enumerate(third_truck_delivery):
    for k in distances.get_addresses():
        if j[1] == k[2]:
            third_truck_distance.append(j[0])
            third_truck_delivery[i][9] = k[0]

# the Greedy Algorithm is called here to sort out which distances are the shortest for each truck

distances.get_route(first_truck_delivery, 0, 0)
distances.get_route(second_truck_delivery, 1, 0)
distances.get_route(third_truck_delivery, 2, 0)

# initial values for truck distance

first_truck_total_distance = 0
second_truck_total_distance = 0
third_truck_total_distance = 0

# these calculate the total distance and time of each truck and updates the hashmap
# O(n)

for i in range(len(distances.get_first_truck_locations())):
    try:
        first_truck_total_distance = distances.get_distance(
            int(distances.get_first_truck_locations()[i]),
            int(distances.get_first_truck_locations()[i + 1]),
            first_truck_total_distance)
        delivery = distances.get_truck_time(
            distances.current_distance(
             int(distances.get_first_truck_locations()[i]),
             int(distances.get_first_truck_locations()[i + 1])),
            first_truck_departure)
        distances.get_first_truck_deliveries()[i][10] = (str(delivery))
        packages.get_hashtable().update(
            int(distances.get_first_truck_deliveries()[i][0]),
            first_truck_delivery)
    except IndexError:
        pass

for i in range(len(distances.get_second_truck_locations())):
    try:
        second_truck_total_distance = distances.get_distance(
            int(distances.get_second_truck_locations()[i]),
            int(distances.get_second_truck_locations()[i + 1]),
            second_truck_total_distance)
        delivery = distances.get_truck_time(
            distances.current_distance(
             int(distances.get_second_truck_locations()[i]),
             int(distances.get_second_truck_locations()[i + 1])),
            second_truck_departure)
        distances.get_second_truck_deliveries()[i][10] = (str(delivery))
        packages.get_hashtable().update(
            int(distances.get_second_truck_deliveries()[i][0]),
            second_truck_delivery)
    except IndexError:
        pass

for i in range(len(distances.get_third_truck_locations())):
    try:
        third_truck_total_distance = distances.get_distance(
            int(distances.get_third_truck_locations()[i]),
            int(distances.get_third_truck_locations()[i + 1]),
            third_truck_total_distance)
        delivery = distances.get_truck_time(
            distances.current_distance(
             int(distances.get_third_truck_locations()[i]),
             int(distances.get_third_truck_locations()[i + 1])),
            third_truck_departure)
        distances.get_third_truck_deliveries()[i][10] = (str(delivery))
        packages.get_hashtable().update(
            int(distances.get_third_truck_deliveries()[i][0]),
            third_truck_delivery)
    except IndexError:
        pass


# retrieve the first truck's distances for use in the main menu print statement
# O(1)
def get_first_truck_total_distance():
    return first_truck_total_distance


# retrieve the second truck's distances for use in the main menu print statement
# O(1)
def get_second_truck_total_distance():
    return second_truck_total_distance


# retrieve the third truck's distances for use in the main menu print statement
# O(1)
def get_third_truck_total_distance():
    return third_truck_total_distance


# retrieve the total truck distance for use in the main menu print statement
# O(1)
def get_total_distances():
    return first_truck_total_distance + \
           second_truck_total_distance + \
           third_truck_total_distance
