
class HashTableEntry:
    def __init__(self, key, item):
        self.key = key
        self.item = item


class HashTable:

    def __init__(self, initial_capacity=16):
        self.table = []
        for i in range(initial_capacity):
            self.table.append([])

    # this function generates a key for the hashmap
    # O(1)
    def key_gen(self, key):
        return int(key) % len(self.table)

    # this function inserts the package info into the hashmap for the specified package ID
    # O(n)
    def insert(self, key, item):
        key_hash = self.key_gen(key)
        key_value = [key, item]

        if self.table[key_hash] is None:
            self.table[key_hash] = list([key_value])
            return True
        else:
            for value in self.table[key_hash]:
                if value[0] == key:
                    value[1] = key_value
                    return True
            self.table[key_hash].append(key_value)
            return True

    # this function updates the specified "package" entry given the package ID
    # O(n)
    def update(self, key, item):
        key_hash = self.key_gen(key)
        if self.table[key_hash] is not None:
            for key_value in self.table[key_hash]:
                if key_value[0] == key:
                    key_value[1] = item
                    print(key_value[1])
                    return True

    # this function retrieves the "key" from the hashmap for referencing
    # O(n)
    def get_key(self, key):
        key_hash = self.key_gen(key)
        if self.table[key_hash] is not None:
            for value in self.table[key_hash]:
                if value[0] == key:
                    return value[1]
        return

    # this function removes an entry based on the specified key
    # O(n)
    def delete(self, key):
        key_hash = self.key_gen(key)
        if self.table[key_hash] is None:
            return False
        for i in range(0, len(self.table[key_hash])):
            if self.table[key_hash][i][0] == key:
                self.table[key_hash].pop(i)
                return True
        return False

