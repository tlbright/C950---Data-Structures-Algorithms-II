# C950 - Data Structures and Algorithms II - Andrew Bright - abrig064 - #001316519
import deliveries
import packages


class Main:
    # I chose to print out the total miles and the individual miles of all three trucks in this "main menu"
    print("\n")
    print('Welcome to the WGUPS Package Tracking System!')
    print(f'Last route was completed in {deliveries.get_total_distances():.2f} miles\n')
    print(f'truck 1 total miles: {deliveries.get_first_truck_total_distance():.2f} miles')
    print(f'truck 2 total miles: {deliveries.get_second_truck_total_distance():.2f} miles')
    print(f'truck 3 total miles: {deliveries.get_third_truck_total_distance():.2f} miles\n')
    print("please choose from the following:\n"
          "1: Search for a package by ID at a specific time \n"
          "2: Print status of all packages at a specific time \n"
          "3: Exit Program \n"
          )

    user_input = int(input('Enter option: '))

    while user_input != -1:

        # this option is to search for a specific package by ID
        # entering a time and ID will call the get_packages function
        if user_input == 1:
            user_time = input('\nPlease enter a time in the 24-hour format HH:MM:SS: ')
            package = (input('Please enter a package ID: '))
            packages.get_packages(user_time, package)
            exit()
        # this option is to print the status of all packages by a specific time
        # entering a time will call the get_packages function with ID value of None
        elif user_input == 2:
            user_time = input('\nPlease enter a time in the 24-hour format HH:MM:SS: ')
            packages.get_packages(user_time, None)
            exit()
        # this exits the program
        elif user_input == 3:
            print('\nExiting Program.')
            exit()
        # this is a generic return that will continuously prompt until a correct answer is given
        else:
            print('Please enter a valid option.\n')
            user_input = int(input('Enter option: '))
