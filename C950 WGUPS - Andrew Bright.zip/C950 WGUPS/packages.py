import csv
import datetime

from hashtable import HashTable

# this opens and reads the formatted packages.csv file
with open('data/packages.csv') as package_csv_file:
    package_csv_reader = csv.reader(package_csv_file, delimiter=',')

    hash_table = HashTable()
    first_truck_delivery = []
    second_truck_delivery = []
    third_truck_delivery = []

    # this for loop inserts "packages" into the hashmap
    # O(n)
    for row in package_csv_reader:
        package_num = row[0]
        address = row[1]
        city = row[2]
        state = row[3]
        zipcode = row[4]
        delivery_time_constraint = row[5]
        weight = row[6]
        special_note = row[7]
        delivery_time = ''
        address_location = ''
        delivery_status = 'at the hub'

        package_entry = [package_num, address, city, state, zipcode, delivery_time_constraint, weight,
                         special_note, delivery_time, address_location, delivery_status]

        key = package_num
        value = package_entry

        # Here, I entered quite a few constraints to separate out the packages based on notes,
        # delivery times and if they were placed into another truck already.
        # All if-else statements here should be of constant time, or O(1)

        # Lines commented out in the if-else statements below were used for debugging and
        # making sure each package was only placed on one truck.

        if 'Must be' in package_entry[7]:
            first_truck_delivery.append(package_entry)
#            print('loaded package %s in truck 1' % package_entry[0])

        if 'Can only be' in package_entry[7] or \
                'Delayed' in package_entry[7]:
            second_truck_delivery.append(package_entry)
#            print('loaded package %s in truck 2' % package_entry[0])

        if 'Wrong address' in package_entry[7]:
            package_entry[1] = '410 S State St'
            package_entry[4] = '84111'
            third_truck_delivery.append(package_entry)
#            print('loaded package %s in truck 3' % package_entry[0])

        if '19' in package_entry[0]:
            first_truck_delivery.append(package_entry)
#            print('loaded package %s in truck 1' % package_entry[0])

        if package_entry in first_truck_delivery or \
                package_entry in second_truck_delivery:
            pass

        elif '9:00' in package_entry[5] or \
                '10:30' in package_entry[5]:
            if len(first_truck_delivery) < 16:
                first_truck_delivery.append(package_entry)
#                print('loaded package %s in truck 1' % package_entry[0])
            elif len(second_truck_delivery) < 16:
                second_truck_delivery.append(package_entry)
#                print('loaded package %s in truck 2' % package_entry[0])
            else:
                pass

        if package_entry in first_truck_delivery or \
                package_entry in second_truck_delivery or \
                package_entry in third_truck_delivery:
            pass
        else:
            if 'EOD' in package_entry[5]:
                if len(third_truck_delivery) < len(second_truck_delivery):
                    third_truck_delivery.append(package_entry)
#                    print('loaded package %s in truck 3' % package_entry[0])
                else:
                    second_truck_delivery.append(package_entry)
#                    print('loaded package %s in truck 2' % package_entry[0])

        hash_table.insert(key, value)

#    print(len(first_truck_delivery))
#    print(len(second_truck_delivery))
#    print(len(third_truck_delivery))

    # retrieve hashmap
    # O(1)
    def get_hashtable():
        return hash_table

    # retrieve the first truck's delivery
    # O(1)
    def get_first_truck_deliveries():
        return first_truck_delivery

    # retrieve the second truck's delivery
    # O(1)
    def get_second_truck_deliveries():
        return second_truck_delivery

    # retrieve the third truck's delivery
    # O(1)
    def get_third_truck_deliveries():
        return third_truck_delivery

    # Here, I decided to make a single function that could be called to print out either a single package,
    # or all packages based on a time or ID. This is the function called in Main.py
    # assumption here is O(n) for the amount of times the function is called, or n
    def get_packages(user_time, package_id):
        (h, m, s) = user_time.split(':')
        user_time_data = datetime.timedelta(
            hours=int(h), minutes=int(m), seconds=int(s))

        if package_id is None:
            # this grabs and converts the two delivery times to be checked against
            # as well as the converted user time passed into the function
            # The case where there is a package_id, the function is basically the same as this one
            # but the only i or index value is the package_id
            for i in range(1, (len(get_first_truck_deliveries()) +
                               len(get_second_truck_deliveries()) +
                               len(get_third_truck_deliveries())) + 1):
                delivery_start_time = get_hashtable().get_key(str(i))[8]
                delivery_status_time = get_hashtable().get_key(str(i))[10]
                (h, m, s) = delivery_start_time.split(':')
                delivery_start_time_data = datetime.timedelta(
                    hours=int(h), minutes=int(m), seconds=int(s))
                (h, m, s) = delivery_status_time.split(':')
                delivery_status_time_data = datetime.timedelta(
                    hours=int(h), minutes=int(m), seconds=int(s))

                # if a package has not left the hub
                if delivery_start_time_data >= user_time_data:
                    get_hashtable().get_key(str(i))[8] = 'Truck leaves at ' + delivery_start_time
                    get_hashtable().get_key(str(i))[10] = 'at the hub'

                    print('Package: %s Address: %s, %s, %s, %s Estimated Delivery Time: %s '
                          'Weight: %s Truck status: %s Delivery status: %s' %
                          (get_hashtable().get_key(str(i))[0],
                           get_hashtable().get_key(str(i))[1],
                           get_hashtable().get_key(str(i))[2],
                           get_hashtable().get_key(str(i))[3],
                           get_hashtable().get_key(str(i))[4],
                           get_hashtable().get_key(str(i))[5],
                           get_hashtable().get_key(str(i))[6],
                           get_hashtable().get_key(str(i))[8],
                           get_hashtable().get_key(str(i))[10]))

                # if a package has left but has not been delivered
                elif delivery_start_time_data <= user_time_data:
                    if user_time_data < delivery_status_time_data:
                        get_hashtable().get_key(str(i))[8] = 'Truck left at ' + delivery_start_time
                        get_hashtable().get_key(str(i))[10] = 'En route'

                        print('Package: %s Address: %s, %s, %s, %s, Estimated Delivery Time: %s '
                              'Weight: %s Truck status: %s Delivery status: %s' %
                              (get_hashtable().get_key(str(i))[0],
                               get_hashtable().get_key(str(i))[1],
                               get_hashtable().get_key(str(i))[2],
                               get_hashtable().get_key(str(i))[3],
                               get_hashtable().get_key(str(i))[4],
                               get_hashtable().get_key(str(i))[5],
                               get_hashtable().get_key(str(i))[6],
                               get_hashtable().get_key(str(i))[8],
                               get_hashtable().get_key(str(i))[10]))

                    # if a package has been delivered
                    else:
                        get_hashtable().get_key(str(i))[8] = 'Truck left at ' + delivery_start_time
                        get_hashtable().get_key(str(i))[10] = 'Delivered at ' + delivery_status_time

                        print('Package: %s Address: %s, %s, %s, %s Estimated Delivery Time: %s '
                              'Weight: %s Truck status: %s Delivery status: %s' %
                              (get_hashtable().get_key(str(i))[0],
                               get_hashtable().get_key(str(i))[1],
                               get_hashtable().get_key(str(i))[2],
                               get_hashtable().get_key(str(i))[3],
                               get_hashtable().get_key(str(i))[4],
                               get_hashtable().get_key(str(i))[5],
                               get_hashtable().get_key(str(i))[6],
                               get_hashtable().get_key(str(i))[8],
                               get_hashtable().get_key(str(i))[10]))

        else:
            delivery_start_time = get_hashtable().get_key(str(package_id))[8]
            delivery_status_time = get_hashtable().get_key(str(package_id))[10]
            (h, m, s) = delivery_start_time.split(':')
            delivery_start_time_data = datetime.timedelta(
                hours=int(h), minutes=int(m), seconds=int(s))
            (h, m, s) = delivery_status_time.split(':')
            delivery_status_time_data = datetime.timedelta(
                hours=int(h), minutes=int(m), seconds=int(s))

            if delivery_start_time_data >= user_time_data:
                get_hashtable().get_key(str(package_id))[8] = 'Truck leaves at ' + delivery_start_time
                get_hashtable().get_key(str(package_id))[10] = 'at the hub'

                print('Package: %s Address: %s, %s, %s, %s Estimated Delivery Time: %s '
                      'Weight: %s Truck status: %s Delivery status: %s' %
                      (get_hashtable().get_key(str(package_id))[0],
                       get_hashtable().get_key(str(package_id))[1],
                       get_hashtable().get_key(str(package_id))[2],
                       get_hashtable().get_key(str(package_id))[3],
                       get_hashtable().get_key(str(package_id))[4],
                       get_hashtable().get_key(str(package_id))[5],
                       get_hashtable().get_key(str(package_id))[6],
                       get_hashtable().get_key(str(package_id))[8],
                       get_hashtable().get_key(str(package_id))[10]))

            elif delivery_start_time_data <= user_time_data:
                if user_time_data < delivery_status_time_data:
                    get_hashtable().get_key(str(package_id))[8] = 'Truck left at ' + delivery_start_time
                    get_hashtable().get_key(str(package_id))[10] = 'En route'

                    print('Package: %s Address: %s, %s, %s, %s Estimated Delivery Time: %s '
                          'Weight: %s Truck status: %s Delivery status: %s' %
                          (get_hashtable().get_key(str(package_id))[0],
                           get_hashtable().get_key(str(package_id))[1],
                           get_hashtable().get_key(str(package_id))[2],
                           get_hashtable().get_key(str(package_id))[3],
                           get_hashtable().get_key(str(package_id))[4],
                           get_hashtable().get_key(str(package_id))[5],
                           get_hashtable().get_key(str(package_id))[6],
                           get_hashtable().get_key(str(package_id))[8],
                           get_hashtable().get_key(str(package_id))[10]))

                else:
                    get_hashtable().get_key(str(package_id))[8] = 'Truck left at ' + delivery_start_time
                    get_hashtable().get_key(str(package_id))[10] = 'Delivered at ' + delivery_status_time

                    print('Package: %s Address: %s, %s, %s, %s Estimated Delivery Time: %s '
                          'Weight: %s Truck status: %s Delivery status: %s' %
                          (get_hashtable().get_key(str(package_id))[0],
                           get_hashtable().get_key(str(package_id))[1],
                           get_hashtable().get_key(str(package_id))[2],
                           get_hashtable().get_key(str(package_id))[3],
                           get_hashtable().get_key(str(package_id))[4],
                           get_hashtable().get_key(str(package_id))[5],
                           get_hashtable().get_key(str(package_id))[6],
                           get_hashtable().get_key(str(package_id))[8],
                           get_hashtable().get_key(str(package_id))[10]))

        return
