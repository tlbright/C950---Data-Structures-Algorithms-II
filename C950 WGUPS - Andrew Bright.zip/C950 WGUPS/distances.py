import csv
import datetime

# these read the distances and addresses csv files and converts them into lists

with open('./data/distances.csv') as distance_csv_file:
    distance_csv_reader = csv.reader(distance_csv_file,
                                     delimiter=',')
    distance_csv_reader = list(distance_csv_reader)

with open('./data/addresses.csv') as address_csv_file:
    address_csv_reader = csv.reader(address_csv_file,
                                    delimiter=',')
    address_csv_reader = list(address_csv_reader)

# finds the distance based on the two values in the csv
# O(N)

    def current_distance(row, col):
        dist = distance_csv_reader[row][col]
        if dist == '':
            dist = distance_csv_reader[col][row]
        return float(dist)

# finds the distance from the values in the csv and adds it to the sum passed into the function
# O(n)

    def get_distance(row, col, dist_sum):
        dist = distance_csv_reader[row][col]
        if dist == '':
            dist = distance_csv_reader[col][row]
        dist_sum += float(dist)
        return dist_sum

# this calculates the time for a specified truck and distance
# O(n)

    def get_truck_time(dist, truck):
        time = dist / 18
        dist_in_min = '{0:02.0f}:{1:02.0f}'.format(
            *divmod(time * 60, 60))
        second_time = dist_in_min + ':00'
        truck.append(second_time)
        time_sum = datetime.timedelta()
        for i in truck:
            (h, m, s) = i.split(':')
            time_sum += datetime.timedelta(
                hours=int(h), minutes=int(m), seconds=int(s))
        return time_sum

    first_truck_deliveries = []
    second_truck_deliveries = []
    third_truck_deliveries = []
    first_truck_location = []
    second_truck_location = []
    third_truck_location = []

    # Here, I have chosen to use a Greedy Algorithm, and specifically involve incursion to iterate through
    # the given truck's delivery list. It uses the truck's list of deliveries, truck number,
    # and current location to calculate the best route for each truck.
    # The base case for this function is the first if statement, which returns an empty list if the list's size is 0.

    # An operation in this function is to set a base distance value, set the distance value equal to the
    # distance to the next point, add the distance to the list of distances, the location to the list of locations,
    # and remove the current item in the list. The function is exited when there are no more values in the list.

    # O(n^2)

    def get_route(truck_list, truck_num, curr_loc):
        if len(truck_list) == 0:
            return truck_list
        dist_value = 30.0
        new_truck_pos = 0
        for i in truck_list:
            if current_distance(curr_loc, int(i[9])) <= dist_value:
                dist_value = current_distance(
                    curr_loc, int(i[9]))
                new_truck_pos = int(i[9])
        for i in truck_list:
            if current_distance(curr_loc, int(i[9])) == dist_value:
                if truck_num == 0:
                    first_truck_deliveries.append(i)
                    first_truck_location.append(i[9])
                    truck_list.pop(truck_list.index(i))
                    curr_loc = new_truck_pos
                    get_route(truck_list, 0, curr_loc)
                elif truck_num == 1:
                    second_truck_deliveries.append(i)
                    second_truck_location.append(i[9])
                    truck_list.pop(truck_list.index(i))
                    curr_loc = new_truck_pos
                    get_route(truck_list, 1, curr_loc)
                elif truck_num == 2:
                    third_truck_deliveries.append(i)
                    third_truck_location.append(i[9])
                    truck_list.pop(truck_list.index(i))
                    curr_loc = new_truck_pos
                    get_route(truck_list, 2, curr_loc)

    first_truck_location.insert(0, '0')
    second_truck_location.insert(0, '0')
    third_truck_location.insert(0, '0')

    # returns the csv of addresses for reference for use in the operations done in deliveries.py
    # O(1)
    def get_addresses():
        return address_csv_reader

    # returns the first truck's deliveries for use in the operations done in deliveries.py
    # O(1)
    def get_first_truck_deliveries():
        return first_truck_deliveries

    # returns the second truck's deliveries for use in the operations done in deliveries.py
    # O(1)
    def get_second_truck_deliveries():
        return second_truck_deliveries

    # returns the third truck's deliveries for use in the operations done in deliveries.py
    # O(1)
    def get_third_truck_deliveries():
        return third_truck_deliveries

    # returns the first truck's location points for use in the operations done in deliveries.py
    # O(1)
    def get_first_truck_locations():
        return first_truck_location

    # returns the second truck's location points for use in the operations done in deliveries.py
    # O(1)
    def get_second_truck_locations():
        return second_truck_location

    # returns the third truck's location points for use in the operations done in deliveries.py
    # O(1)
    def get_third_truck_locations():
        return third_truck_location
